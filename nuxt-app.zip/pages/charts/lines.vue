<template>
    <v-container>
        <v-row>
            <client-only>
                <v-col cols="12" sm="12" md="12">
                    <ChartLine />
                </v-col>

                <v-col cols="12" sm="12" md="7">
                    <ChartBar />
                </v-col>

                <v-col cols="12" sm="12" md="5">
                    <ChartPie />
                </v-col>

                <v-col cols="12" sm="12" md="12">
                    <ChartLineSimple />
                </v-col>

                <v-col cols="12" sm="12" md="12">
                    <ChartMixed />
                </v-col>
            </client-only>
        </v-row>
    </v-container>

</template>