<script setup>
</script>

<template>

  <div>
    <v-alert type="success">I'm a success alert.</v-alert>
  </div>
</template>

<style scoped></style>
