<template>
    <div>
       <h1>Opa</h1>
        <v-icon small>home</v-icon>
    </div>
</template>