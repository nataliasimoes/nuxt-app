<script lang="ts" setup></script>

<template>
  <v-app>
      <v-layout>
        <v-navigation-drawer
          floating
          bottom
        >
          <v-list
            density="compact"
            nav
          >
            <v-list-item prepend-icon="mdi-view-dashboard" title="Home" value="home" nuxt to="/charts/lines" custom></v-list-item>
            <v-list-item prepend-icon="mdi-forum" title="About" value="about" nuxt to="/about"></v-list-item>
            <v-list-item prepend-icon="mdi-form-select" title="Form" value="form" nuxt to="/form"></v-list-item>
          </v-list>
        </v-navigation-drawer>
        <v-main><slot/></v-main>
        
      </v-layout>

  </v-app>
</template>

<style scoped></style>
