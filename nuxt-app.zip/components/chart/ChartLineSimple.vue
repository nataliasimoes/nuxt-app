<template>
  <div>
    <apexchart
      v-if="componentIsActive"
      type="line"
      :options="options"
      :series="series"
    ></apexchart>
  </div>
</template>

<script setup>
const componentIsActive = ref(false);
const activatedComponent = (() => {
  componentIsActive.value = true;
})

setTimeout(activatedComponent, 100);


const options = ref({
  chart: {
    id: "vuechart-example",
  },
  xaxis: {
    categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998],
  },
});

const series = ref([
  {
    name: "series-1",
    data: [30, 40, 45, 50, 49, 60, 70, 91],
  },
  {
    name: "series-2",
    data: [1, 2, 3, 4, 5, 6, 7, 8],
  },
   {
    name: "series-3",
    data: [12, 26, 9, 17, 28, 19, 30, 34],
  },
  {
    name: "series-4",
    data: [22, 16, 5, 23, 27, 29, 30, 65],
  },
]);
</script>
