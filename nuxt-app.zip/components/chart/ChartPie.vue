<template>
 <div id="chart" v-if="componentIsActive">
        <apexchart type="pie" :options="chartOptions" :series="series"></apexchart>
      </div>
</template>

<script setup>

const componentIsActive = ref(false);
const activatedComponent = (() => {
  componentIsActive.value = true;
})

setTimeout(activatedComponent, 100);

const series = ref([ 44, 55, 13, 43, 22])

const chartOptions = ref(
     {
            chart: {
              type: 'pie',
            },
            labels: ['Team A', 'Team B', 'Team C', 'Team D', 'Team E']
          },
        
)
</script>